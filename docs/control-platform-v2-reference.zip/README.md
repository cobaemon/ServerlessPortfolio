# Control Platform v2 Reference Package

This package is a transplantable reference implementation for a policy-centered control platform. It is not applied to the target repository until copied, wired into Codex/Git/CI/IAM, and verified there.

## Contents

- `docs/control-platform-v2-design.md`: formal design.
- `controls/policy.json`: policy-as-code source.
- `scripts/control_platform/engine.py`: dependency-free reference policy engine.
- `scripts/control_platform/cli.py`: CLI used by hooks, wrappers, and tests.
- `skills/*/SKILL.md`: task-specific workflow packages.
- `.codex/hooks.json`: thin hook adapter template.
- `.githooks/*`: Git hook templates.
- `tests/self_test.py`: regression and incident-replay self-test.

## Smoke test

```bash
python -m scripts.control_platform.cli --self-test
python tests/self_test.py
```

## Important

This package is intentionally dependency-free. Production use should connect it to managed hooks, command rules, OS sandbox, least-privilege Git/AWS credentials, CI gates, and RAG source indexing.
