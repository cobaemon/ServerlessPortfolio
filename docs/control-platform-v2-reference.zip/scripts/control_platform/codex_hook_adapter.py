"""Thin Codex hook adapter.

This adapter intentionally performs no AWS/deploy/build/network work. It reads a
hook payload from stdin and delegates to the shared policy engine.
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from scripts.control_platform.engine import classify_prompt, evaluate_command, evaluate_report
else:
    from .engine import classify_prompt, evaluate_command, evaluate_report


def main() -> int:
    """Read JSON from stdin and return a conservative policy decision."""
    try:
        payload = json.load(sys.stdin)
    except Exception:
        print(json.dumps({"decision": "block", "reason": "Invalid hook payload"}))
        return 0

    event = payload.get("hook_event_name") or payload.get("event") or ""
    data = payload.get("tool_input") or payload.get("input") or payload

    if event == "UserPromptSubmit":
        prompt = data.get("prompt", "") if isinstance(data, dict) else str(data)
        contract = classify_prompt(prompt)
        print(json.dumps({"decision": "allow", "context": contract.to_dict()}, ensure_ascii=False))
        return 0

    if event in {"PreToolUse", "PermissionRequest"}:
        command = json.dumps(data, ensure_ascii=False) if isinstance(data, dict) else str(data)
        decision = evaluate_command(command)
        if decision.outcome == "DENY":
            print(json.dumps({"permissionDecision": "deny", "permissionDecisionReason": decision.reason}, ensure_ascii=False))
        else:
            print(json.dumps({"decision": "allow", "context": decision.to_dict()}, ensure_ascii=False))
        return 0

    if event in {"Stop", "SubagentStop"}:
        response = data.get("response", "") if isinstance(data, dict) else str(data)
        decision = evaluate_report(response)
        if decision.outcome in {"NEEDS_EVIDENCE", "DENY_STOP_CONTINUE_PROCEDURE"}:
            print(json.dumps({"decision": "block", "reason": decision.reason}, ensure_ascii=False))
        else:
            print(json.dumps({"decision": "allow"}, ensure_ascii=False))
        return 0

    print(json.dumps({"decision": "allow"}))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
