"""Command-line adapter for Control Platform v2."""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

if __package__ in {None, ""}:
    sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
    from scripts.control_platform.engine import classify_prompt, evaluate_command, evaluate_report, run_self_test
else:
    from .engine import classify_prompt, evaluate_command, evaluate_report, run_self_test


def main(argv=None) -> int:
    """Run the control platform CLI."""
    parser = argparse.ArgumentParser(description="Control Platform v2 reference CLI")
    parser.add_argument("--self-test", action="store_true")
    parser.add_argument("--classify-prompt")
    parser.add_argument("--eval-command")
    parser.add_argument("--eval-report")
    parser.add_argument("--contract-prompt", default="")
    args = parser.parse_args(argv)

    if args.self_test:
        result = run_self_test()
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0 if result["ok"] else 1

    contract = classify_prompt(args.contract_prompt) if args.contract_prompt else None

    if args.classify_prompt is not None:
        print(json.dumps(classify_prompt(args.classify_prompt).to_dict(), ensure_ascii=False, indent=2))
        return 0

    if args.eval_command is not None:
        print(json.dumps(evaluate_command(args.eval_command, contract).to_dict(), ensure_ascii=False, indent=2))
        return 0

    if args.eval_report is not None:
        print(json.dumps(evaluate_report(args.eval_report, contract).to_dict(), ensure_ascii=False, indent=2))
        return 0

    parser.print_help()
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
