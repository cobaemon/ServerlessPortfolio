"""Dependency-free reference policy engine for Control Platform v2.

This module is intentionally conservative. It demonstrates how hooks, wrappers,
Git hooks, CI, and report gates can share the same policy API. Production use
must extend the parser and connect it to real repository state, managed hooks,
IAM, Git credentials, and CI.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List
import hashlib
import json
import re
import shlex

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_POLICY = ROOT / "controls" / "policy.json"


@dataclass
class Contract:
    """Current-turn contract inferred from explicit user instruction."""

    work_type: str
    fixed_procedure: bool = False
    performance_experiment: bool = False
    environment_mutation_allowed: bool = False
    explicit_measurement_procedure: bool = False
    raw_hash: str = ""

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable representation for hooks and audit logs."""
        return asdict(self)


@dataclass
class Decision:
    """Policy decision returned by every control surface."""

    outcome: str
    invariant_ids: List[str]
    reason: str
    allowed_next_actions: List[str]
    evidence_required: List[str]

    def to_dict(self) -> Dict[str, Any]:
        """Return a JSON-serializable representation for hook adapters."""
        return asdict(self)


def load_policy(path: Path = DEFAULT_POLICY) -> Dict[str, Any]:
    """Load the policy-as-code JSON file."""
    return json.loads(path.read_text(encoding="utf-8"))


def _hash(text: str) -> str:
    """Hash text for contract and audit correlation without logging full content."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:16]


def classify_prompt(prompt: str) -> Contract:
    """Classify the user's current turn into a strict work contract.

    This lightweight classifier is a reference implementation. In production,
    replace or augment it with structured prompt classification plus RAG-based
    retrieval of authoritative runbooks.
    """
    text = prompt or ""
    h = _hash(text)
    deploy = bool(re.search(r"STG|ステージング|staging", text, re.I)) and "デプロイ" in text
    perf = bool(re.search(r"性能|速度|起動|cold|ブラウザ|ユーザー視点|体感|FCP|LCP|Navigation", text, re.I))
    incident = "インシデント" in text or "原因" in text and "再発" in text
    control = "制御" in text or "設計" in text
    question_only = bool(re.search(r"なぜ|理由|説明|教えて|確認して", text)) and not bool(re.search(r"実装|修正|作成|デプロイ|反映", text))

    if deploy:
        return Contract("DEPLOY_ALLOWED", fixed_procedure=True, raw_hash=h)
    if perf:
        return Contract("PERFORMANCE_EXPERIMENT", performance_experiment=True, raw_hash=h)
    if incident:
        return Contract("INCIDENT_RESPONSE", raw_hash=h)
    if control:
        return Contract("CONTROL_CHANGE", raw_hash=h)
    if question_only:
        return Contract("QUESTION_ONLY", raw_hash=h)
    return Contract("UNKNOWN_HIGH_RISK", raw_hash=h)


def _tokenize(command: str) -> List[str]:
    """Tokenize shell-ish command text for conservative checks."""
    try:
        return shlex.split(command, posix=True)
    except ValueError:
        return command.split()


def _contains_all(text: str, parts: List[str]) -> bool:
    """Return True when all parts appear in text in any tokenization form."""
    return all(part in text for part in parts)


def evaluate_command(command: str, contract: Contract | None = None, actor: str = "codex") -> Decision:
    """Evaluate a command before execution.

    The engine uses reachability and intent categories, not incident IDs. It
    intentionally denies broad hidden searches, protected asset paths, direct
    environment mutations, and fixed-procedure stop substitutions.
    """
    policy = load_policy()
    command = command or ""
    text = command.strip()
    contract = contract or Contract("UNKNOWN_HIGH_RISK")

    # Human actor is not blocked by AI-only controls; return warn for visibility.
    if actor == "human":
        return Decision("WARN", [], "Human actor is outside AI-only blocking controls.", [], [])

    # Reject shell expansion and protected assets by reachability.
    protected_markers = list(policy["forbidden_asset_patterns"]) + ["$(", "`", "${", "%USERPROFILE%"]
    for marker in protected_markers:
        if marker and marker in text:
            return Decision(
                "DENY",
                ["INV-ASSET-REACHABILITY"],
                f"Command can reach forbidden asset or unresolved expansion marker: {marker}",
                ["Use an explicit allowed repository path."],
                ["Allowed path scope"]
            )

    # Reject broad hidden/ignored/pathless enumeration.
    for pat in policy["forbidden_command_patterns"]:
        if _contains_all(text, pat["contains"]):
            return Decision(
                "DENY",
                ["INV-ASSET-REACHABILITY"],
                f"Forbidden broad enumeration pattern: {pat['id']}",
                ["Search explicit src/tests/docs paths only."],
                ["Explicit target path"]
            )

    # Reject environment mutation unless an explicit safe procedure exists.
    for cmd in policy["aws_environment_mutation_commands"]:
        if text.startswith(cmd) or cmd in text:
            if contract.work_type == "DEPLOY_ALLOWED" and contract.fixed_procedure:
                return Decision("ALLOW", ["INV-FIXED-PROCEDURE"], "Environment mutation is inside explicit fixed deploy procedure.", [], ["post-execution evidence"])
            if contract.explicit_measurement_procedure and contract.environment_mutation_allowed:
                return Decision("ALLOW", ["INV-ENV-MUTATION"], "Environment mutation is inside explicit measurement procedure.", [], ["measurement procedure evidence"])
            return Decision(
                "DENY",
                ["INV-ENV-MUTATION"],
                "STG/prod environment mutation requires fixed deploy or explicit measurement procedure.",
                ["Create or retrieve an explicit procedure before mutation."],
                ["procedure", "rollback", "readiness gates", "cost/risk notice"]
            )

    # Direct live alias measurement is denied even when performance experiment is inferred.
    if "update-alias" in text and "live" in text and contract.work_type == "PERFORMANCE_EXPERIMENT":
        return Decision(
            "DENY",
            ["INV-ENV-MUTATION", "INV-SNAPSTART-READY"],
            "Direct live alias switching for measurement is prohibited without explicit procedure.",
            ["Use fixed deploy or safe measurement procedure with readiness gates."],
            ["SnapStart state", "rollback", "API Gateway 5XX monitoring"]
        )

    return Decision("ALLOW", [], "No blocking invariant matched.", [], [])


def evaluate_report(report: str, contract: Contract | None = None) -> Decision:
    """Evaluate a final or intermediate report before it leaves the agent."""
    policy = load_policy()
    report = report or ""
    contract = contract or Contract("UNKNOWN_HIGH_RISK")

    # Completion claims require an evidence matrix.
    completion_terms = ["完了", "対応済み", "実装済み", "検証済み", "成功", "問題なし", "満たしている", "done", "verified"]
    if any(term in report for term in completion_terms):
        required = ["要件照合", "証跡", "未確認"]
        missing = [term for term in required if term not in report]
        if missing:
            return Decision(
                "NEEDS_EVIDENCE",
                ["INV-REPORT-GATE", "INV-P1-EVIDENCE"],
                f"Completion-like report is missing required sections: {', '.join(missing)}",
                ["Add obligation/evidence/unknown matrix or remove completion claim."],
                required
            )

    # Browser/user-visible claims require browser evidence or explicit unmeasured status.
    if any(term in report for term in policy["performance_browser_terms"]):
        if not any(term in report for term in policy["browser_evidence_terms"]):
            return Decision(
                "NEEDS_EVIDENCE",
                ["INV-PERF-LAYER", "INV-P1-EVIDENCE"],
                "User-visible/browser performance claim lacks browser evidence or unmeasured disclosure.",
                ["Provide Navigation/Paint evidence or mark browser measurement as unmeasured."],
                policy["browser_evidence_terms"]
            )

    # Fixed procedure discretionary stop reports are not allowed.
    if contract.fixed_procedure and any(marker in report for marker in policy["fixed_procedure_forbidden_stop_markers"]):
        return Decision(
            "DENY_STOP_CONTINUE_PROCEDURE",
            ["INV-FIXED-PROCEDURE"],
            "Report attempts to stop a closed procedure using a forbidden stop predicate.",
            ["Continue the next fixed procedure step unless an allowed hard stop predicate exists."],
            ["allowed hard stop predicate evidence if stopping"]
        )

    # Cold-start report cannot use recovery or warm samples as cold-like first request.
    if re.search(r"cold|初回起動|cold-like|初回", report, re.I):
        if any(marker in report for marker in policy["cold_start_forbidden_markers"]):
            return Decision(
                "NEEDS_EVIDENCE",
                ["INV-PERF-LAYER", "INV-SNAPSTART-READY"],
                "Cold-like first request claim uses recovery/warm/stabilized markers.",
                ["Reclassify as recovery/warm or provide valid cold-like first request evidence."],
                ["SnapStart Active/On", "no 5XX", "START/REPORT mapping", "browser navigation/paint"]
            )

    return Decision("ALLOW", [], "Report passes reference gates.", [], [])


def run_self_test() -> Dict[str, Any]:
    """Run dependency-free regression tests for invariant categories."""
    tests = []

    def case(name: str, kind: str, value: str, expected: str, contract: Contract | None = None):
        if kind == "command":
            d = evaluate_command(value, contract)
        else:
            d = evaluate_report(value, contract)
        ok = d.outcome == expected
        tests.append({"name": name, "expected": expected, "actual": d.outcome, "ok": ok, "reason": d.reason})

    case("reject hidden ignored rg", "command", "rg --files --hidden --no-ignore", "DENY")
    case("reject powershell recurse force", "command", "Get-ChildItem -Recurse -Force .", "DENY")
    case("reject protected git config", "command", "cat .git/config", "DENY")
    case("allow explicit repo search", "command", "rg controller src tests", "ALLOW")
    case("reject direct live alias mutation", "command", "aws lambda update-alias --name live --function-name f --function-version 9", "DENY", Contract("PERFORMANCE_EXPERIMENT", performance_experiment=True))
    case("allow fixed deploy mutation", "command", "aws cloudformation deploy --stack-name stg", "ALLOW", Contract("DEPLOY_ALLOWED", fixed_procedure=True))
    case("reject browser claim without evidence", "report", "ユーザーから見た改善は1.7秒です。", "NEEDS_EVIDENCE")
    case("allow browser unmeasured disclosure", "report", "ユーザーから見た改善は未測定です。未測定のため断定しません。", "ALLOW")
    case("reject fixed procedure stop", "report", "origin/dev..v2.0.43 に複数 commit があるため確認が必要です。どちらで進めますか。", "DENY_STOP_CONTINUE_PROCEDURE", Contract("DEPLOY_ALLOWED", fixed_procedure=True))
    case("reject warm as cold", "report", "初回起動比較としてHTTP 500 後の安定後 n=8 を採用した。", "NEEDS_EVIDENCE")
    case("reject completion without matrix", "report", "実装完了しました。", "NEEDS_EVIDENCE")
    case("allow completion with matrix", "report", "要件照合: REQ-1 満足。証跡: test output。未確認: なし。完了。", "ALLOW")

    return {"ok": all(t["ok"] for t in tests), "tests": tests}
