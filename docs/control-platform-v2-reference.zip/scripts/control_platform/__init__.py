"""Control Platform v2 reference implementation."""
