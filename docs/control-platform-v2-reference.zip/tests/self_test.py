#!/usr/bin/env python3
"""Run Control Platform v2 self-tests."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from scripts.control_platform.engine import run_self_test

if __name__ == "__main__":
    report = run_self_test()
    for item in report["tests"]:
        status = "PASS" if item["ok"] else "FAIL"
        print(f"{status}: {item['name']} -> {item['actual']} ({item['reason']})")
    sys.exit(0 if report["ok"] else 1)
