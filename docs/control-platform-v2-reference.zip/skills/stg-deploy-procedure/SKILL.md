---
name: stg-deploy-procedure
description: Execute the closed STG deployment procedure without discretionary push-content stops.
---

# STG Deploy Procedure Skill

Use only when the current contract explicitly allows STG deployment.

## Policy gate
- Requires `DEPLOY_ALLOWED` and `FIXED_PROCEDURE_BOUND`.
- Policy engine remains superior to this skill.

## Forbidden
- Do not stop because `origin/dev..branch` has multiple commits.
- Do not ask whether to split scope unless the user explicitly requested a subset deploy.
- Do not treat post-push evidence as a pre-push prerequisite.

## Required evidence
- Source revision.
- Pipeline state.
- CloudFormation state.
- HTTP/browser evidence required by the contract.
- Unknowns explicitly listed.
