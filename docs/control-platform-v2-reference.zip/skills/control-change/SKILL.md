---
name: control-change
description: Modify the control platform without incident-specific if-statements or unconnected controls.
---

# Control Change Skill

Every control change must update policy, runtime adapter, self-test, documentation, and acceptance criteria together. Do not add incident-id-specific conditions. Map incidents to invariant categories.
