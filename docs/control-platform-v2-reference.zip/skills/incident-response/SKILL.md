---
name: incident-response
description: Record and analyze incidents with root cause, violated invariant, control change, regression test, and residual risk.
---

# Incident Response Skill

## Required sections
- incident record.
- confirmed facts.
- unknowns.
- violated principles.
- violated invariants.
- root cause.
- control change.
- regression self-test.
- verification evidence.
- remaining risk.

Do not report recurrence prevention complete unless control change and regression self-test are implemented and verified.
