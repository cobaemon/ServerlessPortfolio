---
name: evidence-reporting
description: Produce reports that separate facts, evidence, judgments, and unknowns.
---

# Evidence Reporting Skill

Every report item must include evidence or explicitly say that the evidence is missing. Completion claims require an obligation/evidence/unknown matrix.
