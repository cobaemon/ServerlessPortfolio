---
name: performance-verification
description: Verify performance without mixing server, HTTP, browser, paint, real-user, cold-like, and warm samples.
---

# Performance Verification Skill

Use when the contract asks for performance, user-visible improvement, browser validation, memory comparison, SnapStart, or cold start evidence.

## Measurement taxonomy
- server_execution: Lambda Duration / Restore Duration.
- server_platform: Lambda/API Gateway metrics.
- HTTP_client: curl or HTTP client timing.
- browser_navigation: Navigation Timing.
- browser_paint: FCP/LCP.
- RUM: real user telemetry.

## Environment mutation
Changing STG/prod Lambda memory, version, alias, API Gateway, CloudFormation, CodePipeline, or permissions requires a fixed deployment procedure or an explicit measurement procedure.

## Cold-like first request
HTTP 500 after alias/version change invalidates the run. The first 200 after a 500 is recovery-after-failure, not cold-like first request.
