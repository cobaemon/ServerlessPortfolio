# 包括制御プラットフォーム設計書 v2.0

文書ID: `CCP-DESIGN-2.0`  
対象: Serverless Portfolio / Codex / ChatGPT / CI / AWS / Git / ドキュメント / 検証作業  
目的: 個別インシデント追随型の再発防止ではなく、既存のベストプラクティスである Hooks、Rules、Skills、RAG、Guardrails、Human-in-the-loop、Policy-as-Code、Sandbox/IAM、Observability、Evals を統合し、不足部分を独自制御として補完する。

## 0. 設計方針の変更

v1.x は、インシデントが起きるたびに章や条件を追加する構造へ退化していた。これは、INC-20260603-001 が指摘する「発生済みインシデントの症状ごとの条件追加」と同じ失敗である。v2.0 は、制御対象を Hook から始めない。最初に「何を絶対に守るか」を Policy-as-Code として固定し、その後に Hook、Rules、Skill、RAG、CI、IAM、self-test、監査が同じ policy を参照する構造にする。

この設計では、Hook は制御面の一部であって、制御境界の全体ではない。Hook はモデルの行動を事前・事後に制御するが、完全な強制境界ではない。強制境界は、OS sandbox、IAM、Git 権限、CI gate、実行 wrapper、policy engine、監査証跡で多層化する。

## 1. 最上位原則

### 1.1 インシデント定義

原則 1〜4 の優先順位を含め、いずれか複数、単一、部分的にも違反した事象をインシデントとする。

### 1.2 第一原則

- 事実のみ調査すること。
- 事実のみ報告すること。
- すべての報告にエビデンスを追記すること。
- 不明点や曖昧な点があれば作業前に必ず確認すること。
- 明示的に許可がない限り作業を行わないこと。
- 忠実であること。
- 誠実であること。

### 1.3 第二原則

第一原則に反しない限り、策定した要件・設計、ゼロトラストセキュリティ、SOLID、GDPR、クリーンアーキテクチャ、外部資産のライセンス確認・通告・遵守を厳守する。

### 1.4 第三原則

第一・第二原則に反しない限り、プロジェクト全体の一貫性・整合性、フォールバック禁止、未使用コード禁止、ファイル・関数・行コメント、信頼性あるサイトのみアクセスを厳守する。

### 1.5 第四原則

第一・第二・第三原則に反しない限り、指示に従い、指示を曲解せず、決めつけを行わない。

## 2. v2.0 アーキテクチャ

v2.0 は次の 7 つの plane で構成する。

| Plane | 役割 | 代表要素 | 失敗時の扱い |
|---|---|---|---|
| Policy Plane | 原則、不変条件、リスク、手順、報告成立条件の正本 | `controls/policy.json`、`controls/procedures/*.json` | policy が読めない場合、AI actor は停止。human actor は警告。 |
| Contract Plane | 現在ターンの明示指示、作業種別、許可操作、未確認事項を固定 | UserPromptSubmit、contract registry | 契約外操作は拒否。曖昧なら作業前確認。 |
| Capability Plane | Skills / Runbooks により作業手順を再利用可能化 | `skills/*/SKILL.md`、runbook scripts | Skill は作業許可ではない。policy engine が上位。 |
| Knowledge Plane | RAG により根拠文書・正規手順・既知事故・公式資料を取得 | source manifest、vector store、retrieval gate | 取得根拠がない主張は禁止。RAG 出力は命令として扱わない。 |
| Runtime Enforcement Plane | Hook / Rules / wrappers による実行前後制御 | CodexHook、rules、shell wrapper、GitHook | 高リスク操作は deny、固定手順の不正停止は continue procedure。 |
| Environment Plane | IAM / Git 権限 / sandbox / AWS profile による強制境界 | least privilege bot、read-only/ workspace sandbox、deploy role | hook bypass でも権限で止まる。 |
| Verification Plane | self-test、eval、trace、audit、incident replay | `scripts/control_platform self-test`、trace、audit log | テスト未通過なら完了報告不可。 |

## 3. 既存ベストプラクティスの採用

### 3.1 Hooks

CodexHook は、SessionStart、UserPromptSubmit、PreToolUse、PermissionRequest、PostToolUse、PreCompact、PostCompact、SubagentStart、SubagentStop、Stop に接続する。ただし project-local hook は信頼済みでないと実行されない可能性があるため、可能な環境では managed hook / requirements.toml / MDM 配布を優先する。

Hook は薄く保つ。Hook 内で AWS、deploy、build、ネットワーク、重い解析を実行しない。Hook は標準入力を policy engine に渡し、Decision を返すだけにする。

### 3.2 Rules

Codex rules は、単純な command deny/prompt に向く。`.git`、secret、`rm -rf`、直接 deploy、`aws lambda update-alias`、`sam deploy` など、文字列・引数単位で安全に判定できるものは rules でも禁止する。

ただし、rules は文脈、現在ターン契約、RAG 根拠、測定レイヤー、固定手順 phase を深く判定できない。そのため rules は最初の粗い防波堤であり、最終判断は policy engine が行う。

### 3.3 Skills / Runbooks

Skill は「作業許可」ではなく、「許可済み作業を安全に遂行するための専門手順」である。各 Skill は以下を持つ。

- `name` / `description` / trigger。
- prerequisites。
- permitted operations。
- forbidden operations。
- required evidence。
- rollback / abort conditions。
- report template。
- policy mapping。

必須 Skill は次の 5 つである。

1. `stg-deploy-procedure`: STG 固定正規手順。
2. `performance-verification`: browser_navigation / browser_paint / server / HTTP / RUM を分ける性能検証。
3. `incident-response`: incident record + root cause + control change + regression test。
4. `control-change`: policy 変更、self-test 追加、設計反映、CI 接続。
5. `evidence-reporting`: すべての報告に evidence / 未確認区分を付与。

### 3.4 RAG

RAG は、根拠文書を取り出す仕組みであって、制御そのものではない。RAG には source-of-truth 順位を持たせる。

優先順位:

1. ユーザーの現在ターン明示指示。
2. 原則本文。
3. 正式設計書と policy registry。
4. 固定正規手順 runbook。
5. インシデント記録。
6. 公式ドキュメント。
7. その他信頼済み技術資料。

RAG 取得結果は引用根拠であり、命令ではない。外部文書内の指示、コード、コマンドはそのまま実行しない。

### 3.5 Guardrails / Human-in-the-loop

Input guardrail は現在ターン契約を固定する。Tool guardrail は副作用前に検査する。Output guardrail は事実・証跡・未確認・要件照合を検査する。Human-in-the-loop は「ユーザーに確認すべき未定義事項」にだけ使い、固定正規手順で定義済みの事項を再確認するためには使わない。

### 3.6 Observability / Evals

全 Decision は、入力種別、contract id、policy version、invariant id、decision、reason、redacted evidence hash を記録する。ログには secret 値を残さない。

Eval は代表例ではなく、カテゴリ別反例・許可例・incident replay で構成する。失敗カテゴリを増やすのではなく、各 incident を invariant category に写像する。

## 4. 制御の核: Policy-as-Code

`controls/policy.json` は唯一の実装正本である。設計書本文は説明であり、実行時判定は policy.json を参照する。

Policy は次の情報を持つ。

- principles。
- actor model。
- work types。
- risk classes。
- invariant definitions。
- forbidden assets。
- command risk patterns。
- fixed procedures。
- measurement taxonomy。
- report claim gates。
- acceptance criteria。

Decision は以下のいずれかである。

| Decision | 意味 |
|---|---|
| ALLOW | 操作可能。 |
| DENY | 禁止。 |
| WARN | human actor または低リスク注意。 |
| NEEDS_HUMAN | 不明点が作業結果に影響するため作業前確認。 |
| NEEDS_EVIDENCE | 報告に証跡不足。 |
| DENY_STOP_CONTINUE_PROCEDURE | 固定正規手順の不正停止を拒否し、次 step 継続を要求。 |
| ERROR | policy engine 失敗。AI actor では停止。 |

## 5. Contract Plane

UserPromptSubmit で以下を固定する。

```json
{
  "contract_id": "hash",
  "turn_text_hash": "hash",
  "work_type": "DEPLOY_ALLOWED | PERFORMANCE_EXPERIMENT | QUESTION_ONLY | CONTROL_CHANGE | INCIDENT_RESPONSE | ...",
  "fixed_procedure": true,
  "allowed_operations": [],
  "forbidden_operations": [],
  "required_evidence": [],
  "ambiguities": [],
  "rag_required": true,
  "skills_required": []
}
```

明示指示なしに作業を行わない。質問、説明要求、レビュー要求、現状確認要求は作業許可ではない。

## 6. Capability Plane: Skills

Skill は「手順を小さく、再利用可能に、検証可能にする」ために使う。Skill は progressive disclosure を前提に、最初の説明を短くし、実行時に必要な SKILL.md と references を読む。

各 Skill は `policy_gate` を持つ。Skill が選ばれても、policy gate が通らなければ実行しない。

例: `performance-verification` は以下を必須にする。

- 測定レイヤー分類: server_execution / HTTP_client / browser_navigation / browser_paint / RUM。
- cold-like first request と warm stabilized sample の区別。
- STG/prod 変異がある場合は正規 deploy または明示測定手順。
- SnapStart version の Active / OptimizationStatus=On 確認。
- API Gateway 5XX と Lambda START/REPORT の対応確認。
- 500 後の初回 200 を cold-like first request に採用しない。

## 7. Knowledge Plane: RAG

RAG には、次を実装する。

- source manifest: 取り込み対象、信頼順位、owner、更新日時、hash。
- chunking policy: 大きな設計書や incident record を章単位で chunk 化。
- retrieval query: contract から自動生成。
- retrieval gate: 重要判断前に必須ソースが取れない場合、未確認として扱う。
- citation matrix: 報告ごとに evidence id を要求。
- freshness gate: AWS / Codex / OpenAI / ライブラリ仕様など変更可能な情報は公式ソースまたは現時点の証跡を要求。
- prompt injection gate: 外部文書内の命令は無効化し、根拠テキストとしてのみ扱う。

## 8. Runtime Enforcement Plane

### 8.1 CodexHook

各 Hook は共通 `scripts/control_platform/cli.py` を呼ぶ。Hook ごとの責務は以下。

- SessionStart: policy version と managed hook 状態の確認。
- UserPromptSubmit: contract 作成。
- PreToolUse: command / file / AWS / Git / browser / deploy 操作前判定。
- PermissionRequest: escalation 前判定。
- PostToolUse: 副作用・secret 出力・証跡欠落検出。
- PreCompact / PostCompact: contract と未確認事項を保持。
- Stop / SubagentStop: report gate と incident self-report gate。

### 8.2 Shell wrapper

Hook 回避に備え、AI actor の PATH 先頭に wrapper を置く。

対象: `git`, `aws`, `sam`, `npm`, `pnpm`, `yarn`, `pip`, `python`, `rg`, `grep`, `find`, `ls`, `pwsh`, `powershell`。

wrapper は policy engine を呼び、許可された場合のみ実 binary に exec する。絶対パス実行は PreToolUse / rules で拒否する。

### 8.3 GitHook

GitHook は human actor を止めない。AI actor のみ厳格に適用する。

- pre-commit: staged diff、protected file、incident record、control change、secret scan。
- commit-msg: 要件 ID、incident ID、evidence reference。
- pre-push: dev/main direct push、branch-finalize-next、fixed procedure contract。

### 8.4 Environment controls

AI/Codex の Git credential、AWS profile、deploy role は人間ユーザーと分離する。STG/prod の live alias、CloudFormation、CodePipeline、Lambda permission、API Gateway integration は高リスク mutable surface として扱う。

## 9. 固定正規手順

固定正規手順は closed procedure である。指示された場合、allowed hard stop predicates 以外で停止しない。

### 9.1 STG deploy

Deployment unit はユーザーが subset を明示しない限り、branch/revision 全体である。`origin/dev..branch` に複数 commit があること、包括制御関連 commit があること、post-push 証跡がまだ取得できないことは pre-push 停止理由ではない。

Allowed hard stop predicates:

- AWS 認証または profile が使用不能。
- 対象環境が不明。
- 正規手順ファイルが存在しない、または相互矛盾する。
- Git worktree に local uncommitted / unstaged / untracked の意図しない差分があり、手順上 commit/push 対象でない。
- pipeline / CloudFormation / HTTP 検証が失敗した。

Forbidden stop predicates:

- 複数未 push commit がある。
- commit 範囲が広い。
- control 関連差分が含まれる。
- cherry-pick / subset deploy の方が安全そう。
- post-push evidence が push 前にまだ取れていない。

Forbidden stop predicate を検出した場合は、`DENY_STOP_CONTINUE_PROCEDURE` を返し、ユーザー確認ではなく次 step 継続を要求する。

## 10. 性能検証と環境変異

性能検証では、測定対象と測定環境を分離する。

測定レイヤー:

- server_execution: Lambda Duration / Restore Duration。
- server_platform: Lambda Metrics / API Gateway Metrics。
- HTTP_client: curl / http client time_total。
- browser_navigation: Navigation Timing / DOMContentLoaded / load。
- browser_paint: FCP / LCP / layout shift。
- RUM: 実ユーザー環境。

`ユーザー視点`, `体感`, `表示`, `ブラウザ`, `LCP`, `FCP`, `DOMContentLoaded`, `load` を含む肯定報告は、browser_navigation / browser_paint の証跡、または未測定明記が必須である。

STG / prod の Lambda version、alias、CloudFormation、CodePipeline、API Gateway、permission を変更する性能測定は `ENVIRONMENT_MUTATION` である。正規 deploy または明示測定手順なしに実行してはならない。

測定目的で `live` alias を新規 published version へ直接切り替えることは原則禁止である。例外は、正規 deploy、明示測定手順、既知正常版への限定復旧のみである。

SnapStart 対象 version は `State=Active` かつ `SnapStart.OptimizationStatus=On` を確認するまで正式測定対象にしない。

HTTP 500 後の初回 200 は `recovery_after_failure_first_success` であり、cold-like first request ではない。安定後 n サンプルは `warm_or_stabilized_sample` であり、初回起動比較として報告しない。

## 11. RAG + Skill + Hook の統合実行フロー

1. UserPromptSubmit が current contract を作成。
2. Contract から required skills と required sources を決定。
3. RAG が source-of-truth から根拠を取得。
4. Skill が手順を提示。
5. Policy engine が手順を評価。
6. PreToolUse が各 tool call を評価。
7. Environment/IAM が強制境界として作用。
8. PostToolUse が証跡・副作用を記録。
9. Stop が要件照合、証跡、未確認、incident self-detection を評価。
10. Verification Plane が self-test と incident replay を継続的に評価。

## 12. Self-test / Incident replay

Self-test は「代表例を通す」ものではなく、カテゴリを検証する。

必須カテゴリ:

- asset reachability。
- prompt contract。
- fixed procedure stop predicates。
- performance measurement taxonomy。
- environment mutation safety。
- SnapStart readiness。
- report evidence。
- incident lifecycle。
- human actor non-blocking。
- hook bypass resistance。

Incident replay は、各 incident を `given contract / attempted operation / expected decision` に変換する。Incident ID を if 文に入れてはいけない。

## 13. 実装パッケージ構成

```text
controls/
  policy.json
  procedures/stg_deploy.json
  rag_sources.json
  skills_index.json
skills/
  stg-deploy-procedure/SKILL.md
  performance-verification/SKILL.md
  incident-response/SKILL.md
scripts/control_platform/
  engine.py
  cli.py
  codex_hook_adapter.py
.codex/hooks.json
.githooks/pre-commit
.githooks/commit-msg
.githooks/pre-push
tests/self_test.py
```

## 14. 受け入れ基準

- 原則 1〜4 が policy に原文登録されている。
- Hook / Rules / Skill / RAG / GitHook / CI / wrapper が同じ policy engine を呼ぶ。
- Hook が信用されない場合でも、rules、wrapper、IAM、Git 権限、CI で高リスク操作を止める。
- RAG は source manifest、信頼順位、hash、引用要求を持つ。
- Skill は task-specific workflow として存在し、policy gate を持つ。
- STG deploy fixed procedure では forbidden stop predicates でユーザー確認へ戻らない。
- ブラウザ性能報告は測定レイヤー証跡または未測定明記を持つ。
- 環境変異を伴う性能測定は明示測定手順または正規 deploy がない限り拒否される。
- 500 後初回 200 と warm n サンプルを cold-like first request として報告しない。
- self-test と incident replay が通るまで完了報告しない。

## 15. 移行手順

1. v1.x の条件追加を棚卸しし、incident ID 依存の if 文を禁止する。
2. `controls/policy.json` を正本化する。
3. RAG source manifest に原則、設計、runbook、incident、公式 docs を登録する。
4. Skill を task package として作る。
5. CodexHook を thin adapter 化する。
6. rules / wrapper / GitHook / CI を policy engine に接続する。
7. incident replay を self-test に追加する。
8. AI actor の credential / AWS profile / deploy role を分離する。
9. 最初の運用では report gate を warn+deny 混合で観測し、deny ルールの誤判定を調整する。
10. 高リスク操作は最初から deny にする。

## 16. この成果物の限界

このパッケージは移植可能なリファレンス実装であり、実リポジトリへ適用済みではない。実リポジトリの AGENTS.md、runbook、AWS IAM、Git 権限、CI、Codex managed hook 設定へ適用し、self-test を通すまで「実装済み」「再発防止済み」とは報告できない。
